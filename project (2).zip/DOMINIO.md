# Publicar em domínio próprio — camilagoncalves.com.br

Arquivos do site: index.html, site.css, site.js, i18n.js, favicon.svg, assets/, CNAME, robots.txt, sitemap.xml.

## 1. Registrar o domínio
- Registro.br (domínios .com.br): https://registro.br — buscar "camilagoncalves.com.br" (alternativas: camilagoncalvesterapia.com.br, camilagoncalves.com).
- Requer CPF da titular. Custo anual aproximado de R$ 40.

## 2. Hospedar (gratuito)
Qualquer hospedagem estática serve. Opções:
- **Netlify** ou **Vercel**: arraste a pasta do site → em "Domains", adicione camilagoncalves.com.br.
- **GitHub Pages**: suba os arquivos num repositório; o arquivo CNAME já aponta para o domínio.

## 3. Apontar o DNS (no Registro.br → "Editar zona")
| Tipo | Nome | Valor |
|---|---|---|
| A | @ | IP informado pela hospedagem (GitHub Pages: 185.199.108.153, .109.153, .110.153, .111.153) |
| CNAME | www | endereço informado pela hospedagem (ex.: seu-site.netlify.app) |

Ative HTTPS na hospedagem depois que o DNS propagar (até 24h).

## 4. Se o domínio final for outro
Substitua "camilagoncalves.com.br" em: CNAME, robots.txt, sitemap.xml e nas tags <head> do index.html (canonical, hreflang, og:url, og:image, JSON-LD) e no rodapé.
