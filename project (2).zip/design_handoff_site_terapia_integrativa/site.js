(function(){
  // ---------- nav + floating CTA ----------
  const nav = document.getElementById('nav'), wa = document.getElementById('wa');
  const onScroll = () => {
    nav.classList.toggle('scrolled', scrollY > 30);
    const fin = document.getElementById('agendar').getBoundingClientRect().top;
    wa.classList.toggle('show', scrollY > 700 && fin > innerHeight * 0.6);
  };
  addEventListener('scroll', onScroll, {passive:true}); onScroll();

  // mobile menu
  const burger = document.getElementById('burger');
  burger.addEventListener('click', () => nav.classList.toggle('menu-open'));
  document.querySelectorAll('#mobileMenu a').forEach(a => a.addEventListener('click', () => nav.classList.remove('menu-open')));

  // ---------- reveal ----------
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target);} }), {threshold:.12});
  document.querySelectorAll('.reveal').forEach((el,i) => { el.style.transitionDelay = (i%4)*80+'ms'; io.observe(el); });

  // ---------- orbit ----------
  const orbit = document.getElementById('orbit');
  const nodes = [], lbls = [];
  for (let i = 0; i < 5; i++){
    const rad = (-90 + i*72) * Math.PI/180;
    const d = document.createElement('div'); d.className='node';
    d.style.left = (50 + 50*Math.cos(rad))+'%'; d.style.top = (50 + 50*Math.sin(rad))+'%';
    const l = document.createElement('div'); l.className='lbl';
    l.style.left = (50 + 60*Math.cos(rad))+'%'; l.style.top = (50 + 60*Math.sin(rad))+'%';
    orbit.append(d,l); nodes.push(d); lbls.push(l);
  }
  window.setOrbitLabels = names => names.forEach((n,i) => lbls[i].textContent = n);
  const dims = [...document.querySelectorAll('.dim')];
  let cur = 0, timer;
  const setDim = i => { cur=i; [dims,nodes,lbls].forEach(arr => arr.forEach((d,k)=>d.classList.toggle('active',k===i))); };
  const auto = () => { clearInterval(timer); timer = setInterval(()=>setDim((cur+1)%5), 4500); };
  dims.forEach((d,i)=>d.addEventListener('click',()=>{ setDim(i); auto(); }));
  setDim(0); auto();

  // ---------- sobre: ler mais ----------
  const aT = document.getElementById('aboutToggle'), aM = document.getElementById('aboutMore');
  aT.addEventListener('click', () => {
    const open = aT.getAttribute('aria-expanded') !== 'true';
    aT.setAttribute('aria-expanded', open);
    aM.style.maxHeight = open ? aM.scrollHeight + 'px' : 0;
    window.refreshAboutToggle && window.refreshAboutToggle();
  });

  // ---------- faq ----------
  document.querySelectorAll('#faq .q').forEach(q => {
    q.querySelector('button').addEventListener('click', () => {
      const open = q.classList.toggle('open');
      const a = q.querySelector('.a'); a.style.maxHeight = open ? a.scrollHeight+'px' : 0;
    });
  });

  // ---------- language selector ----------
  const lang = document.getElementById('lang'), langBtn = document.getElementById('langBtn');
  langBtn.addEventListener('click', e => {
    e.stopPropagation();
    const o = lang.classList.toggle('open'); langBtn.setAttribute('aria-expanded', o);
  });
  document.addEventListener('click', () => { lang.classList.remove('open'); langBtn.setAttribute('aria-expanded', false); });
  document.querySelectorAll('.lang-menu a').forEach(a => a.addEventListener('click', e => {
    e.preventDefault();
    window.applyLang(a.dataset.lang, true);
    lang.classList.remove('open');
  }));

  const params = new URLSearchParams(location.search);
  let initial = params.get('lang');
  try { initial = initial || localStorage.getItem('cg_lang'); } catch(e){}
  window.applyLang(initial || 'pt', false);
})();
