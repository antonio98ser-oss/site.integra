/* Traduções — o português é lido diretamente do HTML; EN e ES ficam aqui. */
(function(){
  const LI = a => a.map(x => '<li>' + x + '</li>').join('');
  const P  = a => a.map(x => '<p>' + x + '</p>').join('');
  const CH = a => a.map(x => '<span>' + x + '</span>').join('');
  const pain = (t, d) => '<strong>' + t + '</strong>' + d;
  const stk = (a, b) => '<span>' + a + '</span><span>' + b + '</span>';
  const dim = (n, t, d) => '<span class="i">' + n + '</span><h3>' + t + '</h3><p>' + d + '</p>';
  const card = (t, d) => '<h3>' + t + '</h3><p>' + d + '</p>';
  const ARR = ' <span class="arr">→</span>';

  const T = {
    en: {
      _label: 'English', _short: 'EN', _html: 'en',
      _title: 'Camila Gonçalves · Integrative & Holistic Therapy',
      _orbit: ['Emotional','Mental','Energetic','Spiritual','Patterns'],
      _more: 'Read my full journey', _less: 'Show less',
      _wa: 'Hello! I would like to schedule an initial conversation.',
      brand_sub: 'Integrative therapy',
      nav1: 'Approach', nav2: 'How it works', nav3: 'About me', nav4: 'FAQ', nav_cta: 'Book a call',
      h_eb: 'Integrative & holistic therapy',
      h_t: 'You are not a symptom. <em>You are a whole story.</em>',
      h_l: 'A therapeutic process that looks at you as a whole — emotions, mind, energy, spirituality and the patterns formed throughout your life — so that change is deep, not just temporary.',
      h_c1: 'I want to book my session' + ARR, h_c2: 'Is this for me?',
      h_n: 'Online sessions by video call · Limited spots each month',
      h_q: '“When you understand yourself, life shifts into place.”',
      i_eb: 'Maybe you’ll recognize yourself here',
      i_t: 'When something keeps repeating, it’s no accident.',
      i_p: 'Many people come to me after having tried everything. See if any of these situations resonate with you:',
      p1: pain('The same cycles keep repeating', 'Relationships, conflicts, choices — the scenery changes, but the story always seems the same.'),
      p2: pain('Nameless anxiety or distress', 'A constant tightness, a restlessness you can’t explain the source of.'),
      p3: pain('Tiredness that rest doesn’t fix', 'You sleep, take time off, slow down… and still feel drained inside.'),
      p4: pain('Disconnected from yourself', 'The feeling of living on autopilot, of having lost yourself among demands and expectations.'),
      p5: pain('You’ve tried treating “just the symptom”', 'Something improves for a while, then comes back — sometimes in another form.'),
      p6: pain('A call for something more', 'You sense there is a more whole, conscious and true version of you waiting to emerge.'),
      i_c: 'If you identified with at least one of these, <em>there is nothing wrong with you.</em> Something is asking to be understood.',
      i_b: 'Understand why <span class="arr">↓</span>',
      s0: stk('What you feel', 'symptom'), s_w: 'what lies beneath',
      s1: stk('Unacknowledged emotions', 'emotional'), s2: stk('Beliefs and thoughts', 'mental'),
      s3: stk('Blocks and imbalances', 'energetic'), s4: stk('Meaning and purpose', 'spiritual'),
      s5: stk('Patterns from your story', 'root'),
      l_eb: 'Why the symptom comes back', l_t: 'What shows is only the tip.',
      l_b: 'What bothers you today is the visible part of something much deeper.',
      l_p1: 'When we only treat the surface, relief tends to be short-lived. The root is still there — and it finds new ways to show itself.',
      l_p2: 'In integrative therapy, we seek to understand <strong style="color:var(--paper);font-weight:500">what lies beneath</strong> what you live. Lasting change is born from that understanding.',
      a_eb: 'The approach', a_t: 'A perspective that doesn’t fragment you.',
      a_p: 'You are not a set of separate parts. So your care shouldn’t be either.',
      off_tag: 'Isolated view', off_t: 'Focus on the problem only',
      off_ul: LI(['Works on one symptom or issue at a time','Seeks quick relief for what bothers you','Separates body, mind, emotion and spirit','Underlying patterns remain untouched','You depend on something external to feel well']),
      on_tag: 'Integrative therapy', on_t: 'Focus on you, as a whole',
      on_ul: LI(['Understands what lies behind what you live','Considers the emotional, mental, energetic and spiritual dimensions','Recognizes the patterns built throughout your story','Integrates these dimensions for deep, coherent change','Develops your autonomy and self-awareness']),
      d_eb: 'The dimensions of being', d_t: 'Five paths that meet in you.', d_core: 'you',
      d1: dim('01','Emotional','Welcoming and understanding what you feel — including what was kept, silenced or never named.'),
      d2: dim('02','Mental','Recognizing beliefs, thoughts and narratives that shape your choices, often without you noticing.'),
      d3: dim('03','Energetic','Noticing how subtle blocks and imbalances affect your vitality, your body and your inner state.'),
      d4: dim('04','Spiritual','Reconnecting with meaning, purpose and what is essential and true for you.'),
      d5: dim('05','Patterns from your story','Identifying the patterns built over a lifetime — and consciously choosing which ones still make sense.'),
      b_eb: 'What transforms', b_t: 'More awareness. More choice. More you.',
      b_p: 'A process of self-knowledge, integration and expanded consciousness — in which you become more and more present in your own life.',
      b1: card('Clarity about yourself','Understanding why you feel, think and react the way you do.'),
      b2: card('Breaking cycles','Recognizing repetitive patterns and gaining the freedom to do things differently.'),
      b3: card('Conscious choices','Deciding from who you are — not from fear, guilt or autopilot.'),
      b4: card('Peace and coherence','Living with more alignment between what you feel, think and do.'),
      pr_eb: 'How it works', pr_t: 'A path built together with you.',
      pr_p: 'Every process is unique, but the journey follows a clear and safe thread.',
      st1: card('Initial conversation','A first meeting to get to know your story, the moment you’re living and what brought you here.'),
      st2: card('Understanding','Together we look at what lies behind what you feel, mapping the dimensions involved.'),
      st3: card('Integration','Sessions that work on emotions, beliefs, energy and patterns in an integrated way, respecting your pace.'),
      st4: card('Expansion','You take into life a broader awareness of yourself and of how you take part in the reality you live.'),
      f_eb: 'Who it’s for', f_t: 'This process is for you who…',
      f_yes: 'It’s for you if',
      f_yes_ul: LI(['You feel it’s time to look at yourself in depth','You want to understand the root of what you live, not just ease the symptom','You’re willing to become the protagonist of your process','You’re looking for a safe, ethical and welcoming space','You wish to live with more awareness, presence and coherence']),
      f_no: 'Maybe not right now if',
      f_no_ul: LI(['You’re looking for a magic or instant solution','You don’t want to be actively involved in your own transformation','You expect someone else to solve your life for you']),
      f_disc: 'Integrative therapy is complementary and does not replace medical or psychiatric care when needed.',
      fa1: 'start of my therapeutic journey', fa2s: 'Thousands', fa2: 'of hours of sessions',
      ab_eb: 'My journey as a therapist', ab_t: 'Hi, I’m Camila.',
      ab_l: 'My therapeutic journey began in 2020, initially as a path of self-knowledge and personal transformation. Along the way, I went deeper into different approaches and bodies of knowledge that became part of my practice as a therapist.',
      ab_tools: 'I have studied and integrated tools such as:',
      ab_creds: CH(['ThetaHealing','Multidimensional Therapy','Family Constellations','Apometry','Neurobiological Deprogramming','NLP','Hypnosis','Systemic Regression','Psychoanalytic perspective']),
      ab_p1: 'Over time, however, I realized I didn’t want to work with these techniques in isolation, as if each one could explain or solve a specific part of a person. My path was the opposite: I began to see how these different kinds of knowledge could speak to one another and be used in an integrated way, according to each person’s needs and uniqueness.',
      ab_q: '“Each technique becomes a resource within a larger vision, not the center of the process.”',
      ab_more: P(['To this vision I added a deeper look at unconscious processes, also inspired by the psychoanalytic perspective. This broadened the way I understand what lies behind a behavior, a repetition, a difficulty or a symptom.','That is how my approach took shape.','Today, my work starts from a holistic and integrative view of the human being. To me, a person is not just the problem they bring at that moment. There is a story, a system of relationships, experiences, emotions, beliefs, unconscious patterns, energetic aspects and different dimensions of being that may be part of that process.','That’s why I don’t seek to work only on the most visible expression of an issue or to remove a block superficially. I try to understand what sustains that pattern and how it shows up in the whole person.','My work is therefore an integration of the knowledge and tools I gathered along my own journey, combined with the experience of thousands of hours of sessions.','This is how I understand therapy: as a space of awareness, understanding and transformation. A process in which a person can look at themselves more deeply, recognize what once acted unconsciously, reframe experiences, integrate different aspects of themselves and expand their awareness of life and of the choices they make.','More than treating an isolated issue, my purpose is to accompany processes of transformation that reach the human being as a whole — emotional, mental, energetic, spiritual and relational.','It is from this meeting of knowledge, experience, awareness and integration that the therapist I am today was born.']),
      ab_sig: 'With care, Camila', ab_cta: 'I want to start my process' + ARR,
      m_q: '“As you become aware of yourself, your choices and your patterns, <em>the reality you live also begins to change.</em>”',
      q_eb: 'Frequently asked questions', q_t: 'It’s natural to have questions before starting.',
      q_p: 'If yours isn’t here, reach out — I’ll be happy to answer.', q_b: 'Talk to me' + ARR,
      q1: 'What exactly is integrative and holistic therapy?',
      a1: 'It is an approach that considers the person as a whole. Instead of working only on an isolated symptom, we seek to understand what lies behind it — integrating emotional, mental, energetic and spiritual aspects and the patterns of your story.',
      q2: 'Do I need a specific spiritual belief?',
      a2: 'No. The spiritual dimension is approached broadly, as a connection with meaning and purpose, always respecting your personal beliefs and values.',
      q3: 'How do online sessions work?',
      a3: 'Sessions are held remotely by video call, with all the depth and care of the process. You only need a quiet, private place — from any city or country.',
      q4: 'How long until I notice changes?',
      a4: 'Every process is unique. Many people report more clarity in the first sessions, but deep and coherent change is built throughout the process, at your own pace.',
      q5: 'Does integrative therapy replace medical treatment?',
      a5: 'No. It is complementary and can go hand in hand with medical, psychological or psychiatric care, broadening your support.',
      c_eb: 'The first step', c_t: 'You don’t need to understand everything now. <em>You only need to begin.</em>',
      c_p: 'Book an initial conversation and discover how this process can help you live with more awareness, lightness and truth.',
      c_b: 'Book via WhatsApp' + ARR, c_s: 'Reply within 24h · Confidential and caring sessions',
      ft_loc: 'Jacarezinho – PR, Brazil · Online sessions', wa: 'Book a session'
    },
    es: {
      _label: 'Español', _short: 'ES', _html: 'es',
      _title: 'Camila Gonçalves · Terapia Integrativa y Holística',
      _orbit: ['Emocional','Mental','Energética','Espiritual','Patrones'],
      _more: 'Leer mi recorrido completo', _less: 'Mostrar menos',
      _wa: '¡Hola! Me gustaría agendar una conversación inicial.',
      brand_sub: 'Terapia integrativa',
      nav1: 'Enfoque', nav2: 'Cómo funciona', nav3: 'Sobre mí', nav4: 'Preguntas', nav_cta: 'Agendar conversación',
      h_eb: 'Terapia integrativa y holística',
      h_t: 'No eres un síntoma. <em>Eres una historia entera.</em>',
      h_l: 'Un proceso terapéutico que te mira por completo — emociones, mente, energía, espiritualidad y los patrones que se fueron formando a lo largo de tu vida — para que el cambio sea profundo, y no solo temporal.',
      h_c1: 'Quiero agendar mi sesión' + ARR, h_c2: '¿Es para mí?',
      h_n: 'Atención a distancia por videollamada · Plazas limitadas por mes',
      h_q: '“Cuando te comprendes, la vida cambia de lugar.”',
      i_eb: 'Quizás te reconozcas aquí',
      i_t: 'Cuando algo se repite, no es casualidad.',
      i_p: 'Muchas personas llegan a mí después de haberlo intentado todo. Mira si alguna de estas situaciones tiene sentido para ti:',
      p1: pain('Los mismos ciclos se repiten', 'Relaciones, conflictos, decisiones — cambia el escenario, pero la historia parece siempre la misma.'),
      p2: pain('Ansiedad o angustia sin nombre', 'Una opresión constante, una inquietud que no logras explicar de dónde viene.'),
      p3: pain('Cansancio que el descanso no resuelve', 'Duermes, te tomas vacaciones, bajas el ritmo… y aun así te sientes agotada por dentro.'),
      p4: pain('Desconexión de ti misma', 'La sensación de vivir en piloto automático, de haberte perdido entre exigencias y expectativas.'),
      p5: pain('Ya intentaste tratar “solo el síntoma”', 'Algo mejora por un tiempo, pero luego vuelve — a veces de otra forma.'),
      p6: pain('Un llamado a algo más', 'Sientes que existe una versión más entera, consciente y verdadera de ti esperando emerger.'),
      i_c: 'Si te identificaste con al menos una de ellas, <em>no hay nada malo en ti.</em> Hay algo pidiendo ser comprendido.',
      i_b: 'Entiende por qué <span class="arr">↓</span>',
      s0: stk('Lo que sientes', 'síntoma'), s_w: 'lo que hay detrás',
      s1: stk('Emociones no acogidas', 'emocional'), s2: stk('Creencias y pensamientos', 'mental'),
      s3: stk('Bloqueos y desequilibrios', 'energético'), s4: stk('Sentido y propósito', 'espiritual'),
      s5: stk('Patrones de tu historia', 'raíz'),
      l_eb: 'Por qué el síntoma vuelve', l_t: 'Lo que aparece es solo la punta.',
      l_b: 'Lo que te molesta hoy es la parte visible de algo mucho más profundo.',
      l_p1: 'Cuando tratamos solo la superficie, el alivio suele ser pasajero. La raíz sigue ahí — y encuentra nuevas formas de manifestarse.',
      l_p2: 'En la terapia integrativa buscamos comprender <strong style="color:var(--paper);font-weight:500">lo que hay detrás</strong> de lo que vives. De esa comprensión nacen cambios que se sostienen.',
      a_eb: 'El enfoque', a_t: 'Una mirada que no te fragmenta.',
      a_p: 'No eres un conjunto de partes separadas. Por eso, el cuidado tampoco debería serlo.',
      off_tag: 'Mirada aislada', off_t: 'Foco solo en el problema',
      off_ul: LI(['Trabaja un síntoma o tema a la vez','Busca alivio rápido para lo que molesta','Separa cuerpo, mente, emoción y espíritu','Los patrones de fondo siguen intactos','Dependes de algo externo para sentirte bien']),
      on_tag: 'Terapia integrativa', on_t: 'Foco en ti, por entero',
      on_ul: LI(['Comprende lo que hay detrás de lo que vives','Considera las dimensiones emocional, mental, energética y espiritual','Reconoce los patrones construidos a lo largo de tu historia','Integra esas dimensiones para cambios profundos y coherentes','Desarrolla tu autonomía y conciencia sobre ti misma']),
      d_eb: 'Las dimensiones del ser', d_t: 'Cinco caminos que se encuentran en ti.', d_core: 'tú',
      d1: dim('01','Emocional','Acoger y comprender lo que sientes — incluso lo que fue guardado, silenciado o nunca nombrado.'),
      d2: dim('02','Mental','Reconocer creencias, pensamientos y narrativas que moldean tus decisiones, muchas veces sin que lo notes.'),
      d3: dim('03','Energética','Percibir cómo bloqueos y desequilibrios sutiles influyen en tu vitalidad, tu cuerpo y tu estado interno.'),
      d4: dim('04','Espiritual','Reconectar con el sentido, el propósito y con aquello que es esencial y verdadero para ti.'),
      d5: dim('05','Patrones de tu historia','Identificar los patrones construidos a lo largo de la vida — y elegir, con conciencia, cuáles aún tienen sentido.'),
      b_eb: 'Lo que se transforma', b_t: 'Más conciencia. Más elección. Más tú.',
      b_p: 'Un proceso de autoconocimiento, integración y expansión de la conciencia — en el que te vas haciendo cada vez más presente en tu propia vida.',
      b1: card('Claridad sobre ti','Entender por qué sientes, piensas y reaccionas como lo haces.'),
      b2: card('Ruptura de ciclos','Reconocer patrones repetitivos y ganar libertad para hacer algo distinto.'),
      b3: card('Decisiones conscientes','Decidir desde quien eres — no desde el miedo, la culpa o el automático.'),
      b4: card('Paz y coherencia','Vivir con más alineación entre lo que sientes, piensas y haces.'),
      pr_eb: 'Cómo funciona', pr_t: 'Un camino construido junto a ti.',
      pr_p: 'Cada proceso es único, pero el recorrido sigue un hilo conductor claro y seguro.',
      st1: card('Conversación inicial','Un primer encuentro para conocer tu historia, el momento que vives y lo que te trajo hasta aquí.'),
      st2: card('Comprensión','Miramos juntas lo que hay detrás de lo que sientes, mapeando las dimensiones involucradas.'),
      st3: card('Integración','Sesiones que trabajan emociones, creencias, energía y patrones de forma integrada y respetando tu ritmo.'),
      st4: card('Expansión','Llevas a tu vida una conciencia ampliada sobre ti y sobre cómo participas de la realidad que vives.'),
      f_eb: 'Para quién es', f_t: 'Este proceso es para ti que…',
      f_yes: 'Es para ti si',
      f_yes_ul: LI(['Sientes que ya es hora de mirarte con profundidad','Quieres entender la raíz de lo que vives, y no solo aliviar el síntoma','Estás dispuesta a ser protagonista de tu proceso','Buscas un espacio seguro, ético y acogedor','Deseas vivir con más conciencia, presencia y coherencia']),
      f_no: 'Quizás no sea el momento si',
      f_no_ul: LI(['Buscas una solución mágica o instantánea','No deseas involucrarte activamente en tu propia transformación','Esperas que alguien resuelva tu vida por ti']),
      f_disc: 'La terapia integrativa es complementaria y no sustituye el acompañamiento médico o psiquiátrico cuando sea necesario.',
      fa1: 'inicio del recorrido terapéutico', fa2s: 'Miles', fa2: 'de horas de atención',
      ab_eb: 'Mi recorrido como terapeuta', ab_t: 'Hola, soy Camila.',
      ab_l: 'Mi recorrido terapéutico comenzó en 2020, inicialmente como un camino de autoconocimiento y transformación personal. A lo largo de ese proceso fui profundizando en diferentes enfoques y conocimientos que pasaron a formar parte de mi práctica como terapeuta.',
      ab_tools: 'Estudié e integré herramientas como:',
      ab_creds: CH(['ThetaHealing','Terapia Multidimensional','Constelaciones Familiares','Apometría','Desprogramación Neurobiológica','PNL','Hipnosis','Regresión Sistémica','Perspectiva psicoanalítica']),
      ab_p1: 'Con el tiempo, sin embargo, me di cuenta de que no quería trabajar con estas técnicas de manera aislada, como si cada una pudiera explicar o resolver una parte específica de la persona. Mi camino fue justamente el contrario: empecé a percibir cómo estos diferentes conocimientos podían dialogar entre sí y utilizarse de manera integrada, según la necesidad y la singularidad de cada persona.',
      ab_q: '“Cada técnica pasa a ser un recurso dentro de una visión mayor, y no el centro del proceso.”',
      ab_more: P(['A esa visión fui sumando una mirada más profunda hacia los procesos inconscientes, inspirada también en la perspectiva psicoanalítica. Eso amplió mi forma de comprender lo que existe detrás de un comportamiento, de una repetición, de una dificultad o de un síntoma.','Así fue construyéndose mi enfoque.','Hoy, mi trabajo parte de una visión holística e integrativa del ser humano. Para mí, la persona no es solo el problema que presenta en ese momento. Existe una historia, un sistema de relaciones, experiencias, emociones, creencias, patrones inconscientes, aspectos energéticos y diferentes dimensiones del ser que pueden estar participando de ese proceso.','Por eso, no busco trabajar solo la manifestación más aparente de una cuestión ni eliminar un bloqueo de manera superficial. Busco comprender qué sostiene ese patrón y cómo se manifiesta en la totalidad de la persona.','Mi trabajo es, por lo tanto, una integración de los conocimientos y herramientas que fui reuniendo a lo largo de mi propio recorrido, sumados a la experiencia de miles de horas de atención.','Así es como comprendo la terapia: como un espacio de conciencia, comprensión y transformación. Un proceso en el que la persona puede mirarse de manera más profunda, reconocer lo que antes actuaba de forma inconsciente, resignificar experiencias, integrar diferentes aspectos de sí y ampliar su propia conciencia sobre la vida y sobre las decisiones que toma.','Más que tratar una cuestión aislada, mi propósito es acompañar procesos de transformación que alcancen al ser humano como un todo — emocional, mental, energético, espiritual y relacional.','Es de este encuentro entre conocimiento, experiencia, conciencia e integración que nació la terapeuta que soy hoy.']),
      ab_sig: 'Con cariño, Camila', ab_cta: 'Quiero iniciar mi proceso' + ARR,
      m_q: '“A medida que te vuelves consciente de ti, de tus decisiones y de tus patrones, <em>la realidad que vives también comienza a cambiar.</em>”',
      q_eb: 'Preguntas frecuentes', q_t: 'Es natural tener preguntas antes de empezar.',
      q_p: 'Si la tuya no está aquí, escríbeme — con gusto te responderé.', q_b: 'Hablar conmigo' + ARR,
      q1: '¿Qué es, de hecho, la terapia integrativa y holística?',
      a1: 'Es un enfoque que considera a la persona como un todo. En lugar de trabajar solo un síntoma aislado, buscamos comprender lo que hay detrás — integrando aspectos emocionales, mentales, energéticos, espirituales y los patrones de tu historia.',
      q2: '¿Necesito tener alguna creencia espiritual específica?',
      a2: 'No. La dimensión espiritual se trabaja de forma amplia, como conexión con el sentido y el propósito, siempre respetando tus creencias y valores personales.',
      q3: '¿Cómo funcionan las sesiones a distancia?',
      a3: 'Las sesiones se realizan a distancia, por videollamada, con toda la profundidad y el cuidado del proceso. Solo necesitas un lugar tranquilo y reservado — desde cualquier ciudad o país.',
      q4: '¿Cuánto tiempo tarda en notarse el cambio?',
      a4: 'Cada proceso es único. Muchas personas relatan más claridad desde las primeras sesiones, pero los cambios profundos y coherentes se construyen a lo largo del proceso, a tu ritmo.',
      q5: '¿La terapia integrativa sustituye el tratamiento médico?',
      a5: 'No. Es complementaria y puede caminar junto a acompañamientos médicos, psicológicos o psiquiátricos, ampliando tu cuidado.',
      c_eb: 'El primer paso', c_t: 'No necesitas entenderlo todo ahora. <em>Solo necesitas empezar.</em>',
      c_p: 'Agenda una conversación inicial y descubre cómo este proceso puede ayudarte a vivir con más conciencia, ligereza y verdad.',
      c_b: 'Agendar por WhatsApp' + ARR, c_s: 'Respuesta en hasta 24h · Atención confidencial y acogedora',
      ft_loc: 'Jacarezinho – PR, Brasil · Atención online', wa: 'Agendar sesión'
    }
  };

  // Captura o português original do HTML
  const els = [...document.querySelectorAll('[data-i18n]')];
  const PT = { _label: 'Português', _short: 'PT', _html: 'pt-BR', _title: document.title,
    _orbit: ['Emocional','Mental','Energética','Espiritual','Padrões'],
    _more: 'Ler minha jornada completa', _less: 'Recolher',
    _wa: 'Olá! Gostaria de agendar uma conversa inicial.' };
  els.forEach(el => { PT[el.dataset.i18n] = el.innerHTML; });
  T.pt = PT;

  let curLang = 'pt';
  window.refreshAboutToggle = () => {
    const open = document.getElementById('aboutToggle').getAttribute('aria-expanded') === 'true';
    document.getElementById('aboutToggleTxt').textContent = open ? T[curLang]._less : T[curLang]._more;
  };

  window.applyLang = (code, persist) => {
    if (!T[code]) code = 'pt';
    curLang = code;
    const d = T[code];
    els.forEach(el => { const v = d[el.dataset.i18n]; if (v != null) el.innerHTML = v; });
    document.documentElement.lang = d._html;
    document.title = d._title;
    document.getElementById('langFull').textContent = d._label;
    document.getElementById('langShort').textContent = d._short;
    document.querySelectorAll('.lang-menu a').forEach(a => a.toggleAttribute('aria-current', a.dataset.lang === code));
    window.setOrbitLabels && window.setOrbitLabels(d._orbit);
    window.refreshAboutToggle();
    const href = 'https://wa.me/5543988441181?text=' + encodeURIComponent(d._wa);
    document.querySelectorAll('.wa-link').forEach(a => a.href = href);
    // reabre a altura de acordeões abertos após troca de texto
    document.querySelectorAll('#faq .q.open .a').forEach(a => a.style.maxHeight = a.scrollHeight + 'px');
    const aM = document.getElementById('aboutMore');
    if (aM.style.maxHeight && aM.style.maxHeight !== '0px') aM.style.maxHeight = aM.scrollHeight + 'px';
    if (persist) {
      try { localStorage.setItem('cg_lang', code); } catch(e){}
      const u = new URL(location.href);
      if (code === 'pt') u.searchParams.delete('lang'); else u.searchParams.set('lang', code);
      try { history.replaceState(null, '', u); } catch(e){}
    }
  };
})();
