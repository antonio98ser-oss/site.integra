# Handoff: Site Camila Gonçalves · Terapia Integrativa e Holística

## Overview
Landing page de página única (one‑page) para a terapeuta **Camila Gonçalves** (Jacarezinho – PR, atendimento online por videochamada). Objetivo: gerar identificação com a visitante, explicar a abordagem integrativa (emocional, mental, energética, espiritual, padrões da história), apresentar a terapeuta e converter em **agendamento via WhatsApp**. Trilíngue: PT‑BR (padrão), EN, ES.

Domínio previsto: `camilagoncalves.com.br` (ver `DOMINIO.md`).

## About the Design Files
Os arquivos deste pacote são **referências de design feitas em HTML** — protótipos que mostram aparência e comportamento pretendidos. A tarefa é **recriar este design no ambiente do projeto de destino** (React/Next, Astro, Vue etc.) usando seus padrões. Se ainda não houver ambiente, um gerador estático (ex.: **Astro** ou **Next.js com export estático**) é a escolha recomendada: o site é conteúdo estático + pouco JS. Observação: o HTML/CSS/JS atual já é funcional e publicável como está; reimplementar só é necessário para integrar a um codebase/CMS.

## Fidelity
**Alta fidelidade (hi‑fi).** Cores, tipografia, espaçamentos, raios, sombras, textos e interações são finais. Reproduzir pixel a pixel.

---

## Design Tokens

### Cores (definidas em OKLCH em `site.css` — use os mesmos valores; hex aproximados para referência)
| Token | OKLCH | ≈ Hex | Uso |
|---|---|---|---|
| `--ink` | `oklch(0.24 0.035 200)` | `#122a2e` | Petróleo profundo: títulos, seções escuras, botão flutuante |
| `--ink-2` | `oklch(0.32 0.04 195)` | `#223f43` | Reserva |
| `--sage` | `oklch(0.62 0.04 165)` | `#7a9a8c` | Acento sálvia: eyebrows, `<em>` dos títulos, bullets, nós |
| `--sage-soft` | `oklch(0.88 0.025 160)` | `#cfe0d6` | Tag “Terapia integrativa”, borda do card ativo, halo do hero |
| `--sand` | `oklch(0.965 0.012 85)` | `#f6f2ea` | Fundo base (body) |
| `--sand-2` | `oklch(0.93 0.018 80)` | `#ece5d8` | Fundo de “Processo”, coluna “off” |
| `--paper` | `oklch(0.985 0.006 85)` | `#fbf9f5` | Seções claras alternadas, cards, texto sobre escuro |
| `--gold` | `oklch(0.70 0.085 70)` | `#c49a5e` | CTA principal |
| `--gold-deep` | `oklch(0.58 0.09 60)` | `#a0723d` | Hover do CTA |
| `--text` | `oklch(0.28 0.02 200)` | `#283436` | Texto corrido |
| `--muted` | `oklch(0.48 0.02 200)` | `#5b6769` | Texto secundário |
| `--line` | `oklch(0.85 0.015 160)` | `#cdd6d0` | Divisores 1px |
| `--night` | `oklch(0.25 0.01 85)` | `#2b2924` | Fundo da nav (também `theme-color`) |
| `--night-line` | `oklch(1 0 0 / .22)` | branco 22% | Bordas na nav |
| `--night-text` | `oklch(0.86 0.01 85)` | `#d6d3cc` | Links da nav |
| `--night-muted` | `oklch(0.68 0.012 85)` | `#a39f96` | Subtítulo do logo |
| Rodapé bg | `oklch(0.2 0.03 200)` | `#0d1f22` | Footer |

### Tipografia (Google Fonts)
- **Serif:** `Cormorant Garamond` 400/500/600 + itálico 400/500 — todos os títulos (peso 500, line‑height 1.08, letter‑spacing −0.01em, `text-wrap: balance`).
- **Sans:** `Manrope` 300/400/500/600 — corpo. Body: 17px / 1.7, peso 400, cor `--text`.
- **Eyebrow:** 12px, uppercase, letter‑spacing .22em, peso 600, cor `--sage`, precedido por traço 28×1px com gap 12px.

| Elemento | Tamanho |
|---|---|
| H1 hero | `clamp(48px, 6.2vw, 88px)` |
| H2 seção (`.sec-head h2`) | `clamp(38px, 4.4vw, 60px)` |
| H2 Camadas/FAQ/Sobre | `clamp(38px, 4.2vw, 56–58px)` |
| H2 CTA final | `clamp(42px, 5.4vw, 76px)` |
| Manifesto blockquote | `clamp(34px, 4.4vw, 62px)`, peso 400 |
| Lead hero | 20px, peso 300, `--muted`, max 540px |
| Sec-head parágrafo | 19px, peso 300, `--muted` |
| H3 cards | 25–34px serif |

### Layout / espaçamento
- Container `.wrap`: max‑width **1180px**, padding lateral 32px (22px ≤560px).
- Seções: padding vertical **120px** (84px ≤960px). Manifesto 150px; CTA final 140px; hero `170px 0 110px`.
- `.sec-head`: max‑width 760px, margin‑bottom 72px.

### Raios
- Pills/botões: `999px` · Cards benefícios: 24px · Colunas comparação: 28px · Foto sobre: 20px · Hero quote: 16px · Menu idioma: 14px
- Foto hero em arco: `280px 280px 20px 20px` (anel externo `300px 300px 24px 24px`, inset −22px, borda 1px `--line`).

### Sombras
- CTA hover: `0 14px 30px -12px oklch(0.58 0.09 60 / .6)`
- Hero quote: `0 30px 60px -30px oklch(0.24 0.035 200 / .35)`
- Coluna “on”: `0 40px 80px -50px oklch(0.24 0.035 200 / .4)`
- Botão WhatsApp flutuante: `0 20px 40px -18px oklch(0.24 0.035 200 / .7)`
- Nav rolada: `0 10px 30px -20px oklch(0 0 0 / .6)`

### Botões
- Base `.btn`: inline‑flex, gap 12px, padding 18px 32px, radius 999px, Manrope 600 15px, letter‑spacing .02em, transição `all .35s ease`. Seta `.arr` desliza 4px à direita no hover.
- `.btn-gold`: bg `--gold`, texto `--ink`; hover → bg `--gold-deep`, texto `--paper`, `translateY(-2px)` + sombra.
- `.btn-ghost`: borda 1px `--ink`, transparente; hover → bg `--ink`, texto `--paper`.
- `.btn-nav` (na nav): padding 12px 22px, 14px, borda `--night-line`; hover → bg `--paper`, texto `--night`.

---

## Screens / Views (seções da página, em ordem)

### 0. Navegação fixa
- `position: fixed`, altura 76px, bg `--night`. Após 30px de scroll ganha classe `.scrolled`: bg 94% opaco + `backdrop-filter: blur(14px)` + sombra.
- Esquerda: logo = círculo 30px (borda 1px clara, núcleo sálvia inset 7px) + “Camila Gonçalves” (serif 23px) + sub “TERAPIA INTEGRATIVA” (9.5px, .24em).
- Centro: links Abordagem / Como funciona / Sobre mim / Dúvidas (14.5px, gap 36px; 24px ≤1080px; ocultos ≤960px).
- Direita: seletor de idioma (pill; dropdown “Português/English/Español”, item atual em `--gold`; ≤560px mostra só “PT/EN/ES”) + botão “Agendar conversa” (oculto ≤560px) + hambúrguer 44px (≤960px; duas linhas que viram X).
- Menu mobile: expande via max‑height (.45s), links serif 26px, CTA dourado no fim; fecha ao clicar num link.

### 1. Hero (`header.hero`)
- Grid `1.15fr .85fr`, gap 80px. Halo radial 900px `--sage-soft` 70% no canto superior direito.
- Esquerda: eyebrow “Terapia integrativa e holística”; H1 “Você não é um sintoma. *É uma história inteira.*” (itálico em `--sage`); lead; CTAs “Quero agendar minha sessão →” (gold → `#agendar`) e “Entender se é para mim” (ghost → `#identificacao`); nota com ponto sálvia 7px: “Atendimento a distância por videochamada · Vagas limitadas por mês” (13px).
- Direita: `natureza.jpg` aspect 4/5, `object-position: 45% 50%`, formato de arco + anel. Card de citação flutuante (`--paper`, left −60px, bottom 40px, max 260px, serif itálico 20px): “Quando você se compreende, a vida muda de lugar.”

### 2. Identificação (`#identificacao`, bg `--paper`)
- Sec‑head: “Talvez você se reconheça aqui” / “Quando algo se repete, não é por acaso.”
- Grid 3×2 de “dores” com divisores 1px (borda superior, inferior e verticais entre colunas). Cada item: numeral romano itálico sálvia (i.–vi.) + título serif 25px + texto 17px.
- Fechamento: frase serif 32px com trecho em `<em>` sálvia + botão ghost “Entenda por quê ↓” → `#abordagem`.

### 3. Camadas / Iceberg (bg `--ink`)
- Grid 1fr 1fr, gap 90px.
- Esquerda: pilha de pills (borda branca 14%) com larguras progressivas 62% → 74% → 82% → 90% → 96% → 100%. A primeira (“O que você sente / sintoma”) é dourada. Entre ela e o resto, “linha d’água” tracejada com texto “o que está por trás” (11px uppercase). Pills: rótulo serif 24px à esquerda, categoria 12px uppercase à direita.
- Direita: eyebrow dourado, H2 “O que aparece é só a ponta.”, parágrafo grande serif 30px, dois parágrafos 18px/300.

### 4. Abordagem / Comparação (`#abordagem`)
- Duas colunas (gap 28px, radius 28px, padding 52px):
  - **Off** (bg `--sand-2`, texto muted, bullets “—”): tag “Olhar isolado”, “Foco apenas no problema”, 5 itens.
  - **On** (bg `--paper`, borda `--sage-soft`, sombra grande, bullets ponto sálvia 8px): tag “Terapia integrativa”, “Foco em você, por inteiro”, 5 itens.
- Itens com borda superior 1px `--line`, padding 16px 0, 16px.

### 5. Dimensões (bg `--paper`)
- Grid `420px 1fr`, gap 90px.
- **Órbita**: 3 círculos concêntricos (inset 0 / 14% / 28%), núcleo `--ink` (inset 38%) com “você” serif itálico 22px. 5 nós (14px sálvia, halo 6px `--paper`) posicionados a cada 72° partindo do topo, em raio 50%; rótulos (11px uppercase) a raio 60%. Nó ativo: dourado 20px; rótulo ativo `--ink`.
- **Lista acordeão** (5 itens: Emocional, Mental, Energética, Espiritual, Padrões da sua história): número itálico sálvia + H3 30px; descrição expande (max‑height 0 → 140px, .45s). Item ativo: título em `--sage`.
- Sincronizado com a órbita; auto‑avança a cada **4500ms**; clique define o item e reinicia o timer.

### 6. Transformação / Benefícios
- Grid 4 colunas, gap 20px. Cards `--paper`, radius 24px, padding 40px 30px, min‑height 280px, conteúdo empurrado para baixo (space‑between). Hover: `translateY(-6px)`.
- Ícone: círculo 44px borda sálvia com glifo CSS diferente por card (ponto, losango, anel, ponto dourado).
- Cards: Clareza sobre si · Ruptura de ciclos · Escolhas conscientes · Paz e coerência.

### 7. Processo (`#processo`, bg `--sand-2`)
- 4 passos em grid com linha horizontal sálvia 1px a 27px do topo, passando atrás dos números.
- Número: círculo 56px borda sálvia, serif 22px; o 1º é preenchido `--ink` com texto `--paper`.
- Conversa inicial · Compreensão · Integração · Expansão.

### 8. Para quem
- Duas colunas, gap 80px. “É para você se” (5 itens, check com ponto sálvia dentro de círculo 22px) e “Talvez não seja agora se” (3 itens, círculo vazio cinza, texto muted). Aviso 15px muted: terapia complementar, não substitui acompanhamento médico.

### 9. Sobre (`#sobre`, bg `--paper`)
- Grid `.9fr 1.1fr`, gap 100px, `align-items: start`. Coluna da foto é **sticky** (`top: 110px`; estática ≤960px).
- Foto `terapeuta.jpg` 4/5, `object-position: 18% 50%`, radius 20px. Abaixo, 2 fatos: “2020 — início da jornada terapêutica” | “Milhares — de horas de atendimento” (serif 34px).
- Texto: eyebrow, H2 “Olá, eu sou Camila.”, lead 19px, chips de formação (13px, pill borda tracejada sálvia: ThetaHealing, Terapia Multidimensional, Constelação Familiar, Apometria, Desprogramação Neurobiológica, PNL, Hipnose, Regressão Sistêmica, Perspectiva psicanalítica), parágrafo, citação serif itálica 27px entre linhas.
- Bloco **“Ler minha jornada completa”** colapsado (max‑height .6s); botão com ícone +/− circular 30px (fica preenchido `--ink` quando aberto; rótulo vira “Recolher”).
- Assinatura “Com carinho, Camila” serif itálico 30px + CTA “Quero iniciar meu processo →”.

### 10. Manifesto (bg `--sand`, centralizado)
- Blockquote serif max 1000px, trecho final em `<em>` sálvia.

### 11. Dúvidas / FAQ (`#duvidas`, bg `--paper`)
- Grid `.8fr 1.2fr`, gap 90px. Esquerda: título, texto, botão ghost “Falar comigo →”.
- Direita: 5 perguntas acordeão; pergunta serif 25px; ícone +/− 34px (preenche `--ink` quando aberto); resposta expande via max‑height (.45s). Múltiplas podem ficar abertas.

### 12. CTA final (`#agendar`, bg `--ink`)
- Centralizado; anéis decorativos concêntricos (800px, bordas/box‑shadows brancas 8% / 2% / 1.5%).
- Eyebrow dourado “O primeiro passo”; H2 com `<em>` em `--gold`; parágrafo; botão gold maior (22px 40px, 16px) “Agendar pelo WhatsApp →”; nota 13px “Resposta em até 24h · Atendimento sigiloso e acolhedor”.

### Rodapé
- bg `oklch(0.2 0.03 200)`, 14px. Logo · “Jacarezinho – PR · Atendimento online · WhatsApp (43) 98844‑1181 · @camilamg.pereira” · “© 2026 camilagoncalves.com.br”.

### Botão WhatsApp flutuante
- Fixo bottom/right 28px, pill `--ink`, ponto dourado com animação `pulse` (2s infinito). Aparece quando `scrollY > 700` **e** a seção `#agendar` ainda não entrou (topo > 60% da viewport). Hover sobe 3px.

---

## Interactions & Behavior
- **Scroll suave** para âncoras (`scroll-behavior: smooth`, `scroll-margin-top` 60–76px).
- **Reveal on scroll**: `.reveal` começa `opacity 0, translateY(28px)`; IntersectionObserver (threshold .12) adiciona `.in` (transição 1s ease). Atraso escalonado `(index % 4) * 80ms`. Dispara uma vez.
- **Nav**: classe `.scrolled` após 30px.
- **Hambúrguer**: alterna `nav.menu-open`.
- **Seletor de idioma**: abre/fecha ao clicar; fecha ao clicar fora.
- **Órbita/Dimensões**, **Sobre “ler mais”**, **FAQ**: ver seções acima. Acordeões usam `max-height = scrollHeight` (recalcular após troca de idioma).
- **WhatsApp**: `https://wa.me/5543988441181?text=<mensagem codificada no idioma atual>` — todos os elementos `.wa-link` são atualizados ao trocar idioma.

### Responsivo
- **≤1080px**: gap dos links da nav 24px.
- **≤960px**: seções 84px; todas as grades de 2 colunas viram 1 coluna (gap 50px); dores 1 coluna; benefícios e passos 2 colunas (linha dos passos oculta); hero‑quote reposicionado (left/bottom 16px); órbita max 360px centralizada; menu hambúrguer.
- **≤560px**: wrap 22px; benefícios e passos 1 coluna; botão de agendar da nav oculto; seletor de idioma compacto.

## State Management
- `lang`: `'pt' | 'en' | 'es'`. Ordem de resolução inicial: query `?lang=` → `localStorage['cg_lang']` → `'pt'`. Ao trocar: persiste em localStorage e atualiza a URL via `history.replaceState` (remove o parâmetro para `pt`). Atualiza `<html lang>`, `document.title`, rótulos da órbita, texto do toggle Sobre, links do WhatsApp.
- `activeDim`: 0–4 + timer de auto‑avanço 4500ms.
- `aboutExpanded`: boolean. `faqOpen`: conjunto de índices abertos. `menuOpen`, `langMenuOpen`: boolean.
- `scrolled` / `showFloatingCta`: derivados do scroll.
- Sem fetch de dados; todo conteúdo é estático.

## i18n
- `i18n.js` contém o dicionário `T.en` e `T.es`; o PT é extraído do próprio HTML na carga (cada elemento com `data-i18n="chave"` tem seu `innerHTML` capturado). Valores são **HTML** (contêm `<em>`, `<strong>`, `<li>`, `<span>`). Chaves especiais: `_label`, `_short`, `_html`, `_title`, `_orbit` (5 rótulos), `_more`, `_less`, `_wa`.
- Recomendação para reimplementação: mover os três idiomas para arquivos de mensagens (JSON/MDX) e gerar rotas estáticas por idioma (`/`, `/en/`, `/es/`) mantendo as tags `hreflang`.

## SEO / Meta (manter)
- `title`, `description`, `canonical`, `hreflang` (pt‑BR/en/es), Open Graph (`og:image` = terapeuta.jpg), `twitter:card`, `theme-color #2b2924`.
- JSON‑LD `ProfessionalService` (nome, URL, imagem, telefone +55 43 98844‑1181, Jacarezinho/PR/BR, Instagram).
- `robots.txt`, `sitemap.xml`, `CNAME` incluídos.

## Assets
| Arquivo | Uso | Observação |
|---|---|---|
| `assets/natureza.jpg` | Foto do hero (caminho na natureza) | **1,7 MB** — otimizar (WebP/AVIF, ~1200px de largura, `srcset`) |
| `assets/terapeuta.jpg` | Foto da seção Sobre + og:image | 65 KB, fornecida pela cliente |
| `favicon.svg` | Favicon | — |
- Ícones dos cards, logo e decorações são feitos em CSS puro (sem imagens).
- Fontes: Google Fonts (Cormorant Garamond, Manrope).

## Files
- `index.html` — marcação completa e textos em PT‑BR (fonte da verdade do conteúdo).
- `site.css` — todos os tokens e estilos.
- `site.js` — nav, menu mobile, reveal, órbita, acordeões, seletor de idioma.
- `i18n.js` — traduções EN/ES e lógica `applyLang`.
- `favicon.svg`, `assets/` — mídia.
- `CNAME`, `robots.txt`, `sitemap.xml`, `DOMINIO.md` — publicação no domínio próprio.
